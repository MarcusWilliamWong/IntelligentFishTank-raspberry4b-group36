#include <vector>
#include <algorithm>
#include <numeric>
#include <tuple>
#include <iostream>
#include <mutex>
#include <thread>
#include <chrono>
#include <pigpio.h>
#include "heater.h"

// Test only
// #define DEBUG_THREADTASK


Heater::Heater(unsigned int pin) : PwmController(pin) {}

Heater::Heater(unsigned int pin, unsigned int freq) 
	: PwmController(pin, freq) {}

Heater::~Heater() {
	if (running_) {
		this->stop(); 
	}
}

// bottom task, compute 4 temperatures return tuple including the average, minimum, maximum
void Heater::ProcessTempers(const std::vector<double> &tempers) {
	// std::cout << TAG_THERMOMETER << "measure Average T(°C): " 
	// 					<< std::get<0>(tempsInfo_) << std::endl;

	auto minmax = std::minmax_element(tempers.cbegin(), tempers.cend());
	double average = 0.0;
	if (!tempers.empty()) {
		average = std::accumulate(tempers.cbegin(), tempers.cend(), 0.0) / tempers.size();
	}
	{	
		// only lock when writing data
		std::lock_guard<std::mutex> lock(mtx_);
		tempsInfo_ = std::move(std::make_tuple(average, *minmax.first, *minmax.second));

		#ifdef DEBUG_THREADTASK
		std::cout << TAG_HEATER << "ProcessTempers here" << std::endl;
		#endif
	}
	
}

// bottom task, automatically control heater on and off
void Heater::AutoControlHeater() {
	std::cout << TAG_HEATER << "AutoControlHeater, "
						<< "Average T(°C): " << std::get<0>(tempsInfo_)
						<< std::endl;

	// initialise two flags
	needOn_flag_ = true;
	needOff_flag_ = true;
	while (running_) {
		// if tempsInfo is still not write by `ProcessTemps`
		// just sleep and wait for thermometer catch the first temperature
		if (!std::get<0>(tempsInfo_)) {
			#ifdef DEBUG_THREADTASK
			std::cout << TAG_HEATER << "AutoControlHeater here" << std::endl;
			#endif
			continue;
		}
		// if current average temp lower than min threshold
		if (std::get<0>(tempsInfo_) < std::get<0>(tempRange_)) {
			turnOn();
			std::cout << " lower than min " << std::get<0>(tempRange_) 
								<< " open heater" << std::endl;
		} else if (std::get<0>(tempsInfo_) > std::get<1>(tempRange_)) {
			turnOff();
			std::cout << " higher than max " << std::get<1>(tempRange_)
								<< " close heater" << std::endl;
		} else {
			#ifdef DEBUG_HEATER
			std::cout << "is between the range" << std::endl;
			#endif
		}
	}
}

// automatically turnOn
void Heater::turnOn() {
	#ifdef DEBUG_HEATER
	// setPwmLvl('3');
	#endif
	// start configed PWM level on GPIO, if configured as lvl0, automatically set lvl2
	if (0u == dutycycle_) {
		setPwmLvl('2');
	}
  gpioPWM(kPin_, dutycycle_);
	// heater until current average temperature is higher than max threshold
	while (needOn_flag_) {
		#ifdef DEBUG_THREADTASK
		std::cout << TAG_HEATER << "turnOn here" << std::get<0>(tempsInfo_) << std::endl;
		#endif
		if (std::get<0>(tempsInfo_) > std::get<1>(tempRange_)) {
			std::cout << TAG_HEATER << "Average T(°C): " << std::get<0>(tempsInfo_)
								<< " higher than max threshold" << std::endl;
			// change flags and exit loop
			needOn_flag_ = false;
			needOff_flag_ = true;
			break;
		}
	}
	// reset needOn_flag_
	needOn_flag_ = true;
}

// automatically turnOff
void Heater::turnOff() {
  gpioPWM(kPin_, 0);
	// wait for water cool until min threshold
	while (needOff_flag_) {
		// if current water temperatur is higher than max threshold
		if (std::get<0>(tempsInfo_) < std::get<0>(tempRange_)) {
			std::cout << TAG_HEATER << "Average T(°C): " << std::get<0>(tempsInfo_)
								<< " lower than min threshold" << std::endl;
			// change flags and exit loop
			needOn_flag_ = true;
			needOff_flag_ = false;
			break;
		}
	}
	// reset needOff_flag_
	needOff_flag_ = true;
}

void Heater::set(char lvl) {
  // set pwm level
  setPwmLvl(lvl);
  // Starts PWM on the GPIO
  int ret = gpioPWM(kPin_, dutycycle_);
  if (ret != 0) {
    std::cerr << TAG_HEATER
              << "failed to set dutycycle: " << dutycycle_
              << " on gpio: " << kPin_ << " with err code: " << ret
              << std::endl;
  }
}

void Heater::stop() {
	running_ = false;
  // set pwm level
  setPwmLvl('0');
  int ret = gpioPWM(kPin_, 0);
  if (ret != 0) {
    std::cerr << TAG_HEATER
              << "failed to set dutycycle: " << dutycycle_
              << " on gpio: " << kPin_ << " with err code: " << ret
              << std::endl;
  }
}




