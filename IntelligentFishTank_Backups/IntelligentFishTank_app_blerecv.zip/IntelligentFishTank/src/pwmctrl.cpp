#include <pigpio.h>
#include <memory>
#include "pwmctrl.h"

#include <iostream>

PwmController::PwmController(unsigned int pin) : PwmController(pin, 50u) {}

PwmController::PwmController(unsigned int pin, unsigned int freq) : kPin_(pin), kRange_(1000u), freq_(freq), dutycycle_(static_cast<unsigned int>(PwmLevel::PwmLvl0)), running_(true) {
  // initiation, set pin, freq and range(precision)
  gpioSetMode(kPin_, PI_ALT5);
  gpioSetPWMfrequency(kPin_, freq_);
  gpioSetPWMrange(kPin_, kRange_);
	gpioPWM(kPin_, static_cast<unsigned int>(PwmLevel::PwmLvl0));
}

void PwmController::setPwmLvl(unsigned int level) {
	switch (level) {
		case 0u: 
			dutycycle_ = static_cast<unsigned int>(PwmLevel::PwmLvl0); 
			break;
		case 1u: 
			dutycycle_ = static_cast<unsigned int>(PwmLevel::PwmLvl1); 
			break;
		case 2u: 
			dutycycle_ = static_cast<unsigned int>(PwmLevel::PwmLvl2); 
			break;
		case 3u: 
			dutycycle_ = static_cast<unsigned int>(PwmLevel::PwmLvl3); 
			break;
		case 4u: 
			dutycycle_ = static_cast<unsigned int>(PwmLevel::PwmLvl4); 
			break;
		default:
			dutycycle_ = static_cast<unsigned int>(PwmLevel::PwmLvl0);
			break;
	}
}

bool PwmController::isRunning() {
	return running_;
}