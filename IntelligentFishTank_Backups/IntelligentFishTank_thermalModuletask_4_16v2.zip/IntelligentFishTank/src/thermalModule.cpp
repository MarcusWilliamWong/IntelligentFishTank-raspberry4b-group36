#include <functional>
#include <tuple>
// #include <future>
#include "thermalModule.h"
#include "config.h"
#include "threadPool.h"

// create thermalModule tasks
ThermalModule::ThermalModule() : Module(), tempRange_(24.0, 25.0) {
	thermometer_ptr_.reset(new Thermometer());
	heater_ptr_.reset(new Heater(app_config::HEATER_PIN));
	thermometer_ptr_->registerHeater(heater_ptr_);
}

ThermalModule::~ThermalModule() {
	if (running_) {
		this->stop(); 
	}
}

void ThermalModule::registerBluetooth(std::shared_ptr<Bluetooth> &bluetooth_ptr) {
	bluetooth_ptr_ = bluetooth_ptr;
}

// Callback function, thermometer read temperatures
void ThermalModule::executeReadAllTemperature() {
	std::cout << TAG_THERMOMETER << "running `ReadAllTemperature` task..." << std::endl;

	thermometer_ptr_->start();
}

// Callback function, automatically control heater via thermometer
void ThermalModule::executeAutoControlHeater() {
	std::cout << TAG_THERMOMETER << "running `AutoControlHeater` task..." << std::endl;

	heater_ptr_->AutoControlHeater();
}


// callbakc function, thermometer control heater
// void ThermalModule::executeAutoControlHeater() {
// 	std::cout << TAG_THERMALMODULE << "running `AutoControlHeater` task..." << std::endl;

// 	bool turnOn_flag = true;
// 	bool turnOff_flag = true;
// 	while (running_) {
// 		// std::cout << std::get<0>(heater_.getTempsInfo()) << "`C\n" << std::endl;
// 		// if current average temp lower than min threshold
// 		if (std::get<0>(heater_ptr_->getTempsInfo()) < std::get<0>(tempRange_)) {
// 			std::cout << "current average t = " << std::get<0>(heater_ptr_.getTempsInfo()) << ", lower than min" << std::endl;
// 			// if (turnOn_flag) {
// 			// 	heater_.turnOn();
// 			// 	~turnOn_flag;
// 			// 	turnOff_flag = true;
// 			// }
// 		} else if (std::get<0>(heater_.getTempsInfo()) > std::get<1>(tempRange_)) {
// 			std::cout << "current average t = " << std::get<0>(heater_.getTempsInfo()) << ", higher than max" << std::endl;
// 			// if (turnOff_flag) {
// 			// 	heater_.turnOff();
// 			// 	~turnOff_flag;
// 			// 	turnOn_flag = true;
// 			// }
// 		}
// 	}
// }

// stop all related equipments
void ThermalModule::stop() {
	if (running_) {
		running_ = false;
	}
	thermometer_ptr_->stop();
	heater_ptr_->stop();
}

void ThermalModule::execute() {
	
	// while (true) {
		// auto task1 = std::bind(&Thermometer::turnOn, std::ref(thermometer_));

	// std::packaged_task<void()> f(task);
	// pool_ptr_->AddTask(std::move(f));
	// pool_ptr_->AddTask([this]{ });

	// thermo_thread_ptr_ = std::make_shared<std::thread>(&Thermometer::turnOn, &thermometer_);

	// std::tuple<double, double> tempRange_ = std::make_tuple<double, double>(24.0, 40.0);
	// auto task2 = std::bind(&Heater::ControlHeater, std::ref(heater_));
	// pool_ptr_->AddTask([this]{  });
	// heater_thread_ptr_ = std::make_shared<std::thread>(&Heater::ControlHeater, &heater_);
	// }
	
	// thermo_thread_ptr_->detach();
	// heater_thread_ptr_->detach();
}