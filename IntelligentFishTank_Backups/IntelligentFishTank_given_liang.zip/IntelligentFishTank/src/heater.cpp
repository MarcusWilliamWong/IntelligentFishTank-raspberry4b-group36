#include <vector>
#include <algorithm>
#include <numeric>
#include <tuple>
#include <mutex>
#include <pigpio.h>
#include "heater.h"

#include <iostream>

Heater::Heater(unsigned int pin) : PwmController(pin), running_(true) {}

Heater::Heater(unsigned int pin, unsigned int freq) : PwmController(pin, freq), running_(true) {}

void Heater::turnOn() {
	std::cout << "heater turn on" << std::endl;
	setPwmLevel(5);
  gpioPWM(kPin_, dutycycle_);
	std::cout << "gpioGetPWM : " << gpioGetPWMdutycycle(kPin_) << "; dutycycle : " << dutycycle_ << std::endl;
}

void Heater::turnOff() {
	std::cout << "heater turn off" << std::endl;
	setPwmLevel(0);
  gpioPWM(kPin_, 0);
}

// compute 4 temperatures return tuple including the average, minimum, maximum
void Heater::ProcessTempers(const std::vector<double> &tempers) {
	auto minmax = std::minmax_element(tempers.cbegin(), tempers.cend());
	double average = 0.0;
	if (!tempers.empty()) {
		average = std::accumulate(tempers.cbegin(), tempers.cend(), 0.0) / tempers.size();
	}
	tempsInfo_ = std::move(std::make_tuple(average, *minmax.first, *minmax.second));
}

// conditional n off heater
void Heater::ControlHeater() {
	bool turnOn_flag = true;
	bool turnOff_flag = true;
	while (running_) {
		// std::lock_guard<std::mutex> lock(mtx);
		std::cout << std::get<0>(tempsInfo_) << "`C\n" << std::endl;
		// if current average temp lower than min threshold
		if (std::get<0>(tempsInfo_) < std::get<0>(tempRange_)) {
			std::cout << "current average t = " << std::get<0>(tempsInfo_) << ", lower than min" << std::endl;
			if (turnOn_flag) {
				turnOn();
				~turnOn_flag;
				turnOff_flag = true;
			}
		} else if (std::get<0>(tempsInfo_) > std::get<1>(tempRange_)) {
			std::cout << "current average t = " << std::get<0>(tempsInfo_) << ", higher than max" << std::endl;
			if (turnOff_flag) {
				turnOff();
				~turnOff_flag;
				turnOn_flag = true;
			}
		}
	}
}

