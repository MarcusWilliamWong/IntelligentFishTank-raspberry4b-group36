#include <pigpio.h>
#include <cstring>
#include <stdexcept>
#include "app.h"
#include "config.h"


// #define DEBUG

// initialise threadpool, modules and bluetooth
App::App() : pool_ptr_(new ThreadPool()) {
  if (gpioInitialise() < 0) {
    throw std::runtime_error("failed to init PIGPIO!");
  }
  thermalModule_ptr_.reset(new ThermalModule());
  // pumpModule_ptr_.reset(new PumpModule());
  bluetooth_ptr_.reset(new Bluetooth(app_config::BLUETOOTH_DEV_PATH));
  waterpump_ptr_.reset(new Waterpump(app_config::WATERUMP_PIN));
}

void App::run() {
  if (!running_) {
    running_ = true;
    std::cout << TAG_APP << "running..." << std::endl;
    // add module tasks into thraed pool
    AddModuleTasks();
    // main thread do nothing just sleep
    while(true) {
      std::this_thread::sleep_for(std::chrono::seconds(2));
    }
  } else {
    std::cerr << TAG_APP << "already running!" << std::endl;
  }
}

// check app running status
bool App::isRunning() const { return running_; }

// terminate pigpio
App::~App() {
  thermalModule_ptr_->stop();
  gpioTerminate();
}

// add module tasks into thraed pool
void App::AddModuleTasks() {  
  pool_ptr_->AddTask([this]{ this->bluetooth_ptr_->executeRecvCmd(); });
  pool_ptr_->AddTask([this]{ this->thermalModule_ptr_->executeReadAllTemperature(); });
  pool_ptr_->AddTask([this]{ this->thermalModule_ptr_->executeAutoControlHeater(); });
}

// void App::runWaterpump() {
//   std::cout << TAG_WATERPUMP << "running..." << std::endl;
//     while (true) {
//         std::unique_lock<std::mutex> lock(this->cmd_mut_);
//         while (bluetooth_ptr_->cmd_que_.empty()) {
//             this->cmd_cond_.wait(lock);
//         }
//         CmdType cmd(this->cmd_que_.front());
//         this->cmd_que_.pop();
//         std::cout << TAG_WATERPUMP
//                   << "received cmd: " << static_cast<unsigned int>(cmd)
//                   << std::endl;

//         bool valid_cmd(true);
//         switch (cmd) {
//         case CmdType::SetWaterPumpLvl0:
//             this->waterpump_->setPwmLevel(0);
//             break;
//         case CmdType::SetWaterPumpLvl1:
//             this->waterpump_->setPwmLevel(1);
//             break;
//         case CmdType::SetWaterPumpLvl2:
//             this->waterpump_->setPwmLevel(2);
//             break;
//         case CmdType::SetWaterPumpLvl3:
//             this->waterpump_->setPwmLevel(3);
//             break;
//         case CmdType::SetWaterPumpLvl4:
//             this->waterpump_->setPwmLevel(4);
//             break;
//         default:
//             valid_cmd = false;
//             std::cerr << TAG_WATERPUMP
//                       << "unknown cmd: " << static_cast<unsigned int>(cmd)
//                       << std::endl;
//             break;
//         }
//         if (valid_cmd) {
//             this->waterpump_->set();
//         }
//     }
// }

