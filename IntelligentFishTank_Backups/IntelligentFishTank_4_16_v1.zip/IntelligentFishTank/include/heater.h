#ifndef HEATER_H_
#define HEATER_H_

#define TAG_HEATER "heater : "

#include <tuple>
#include <mutex>
#include <vector>
#include "pwmctrl.h"

// Test only
// #define DEBUG

// we use GPIO 26 to connect heater pwm
class Heater : public PwmController {
public:
	Heater(unsigned int pin);
	Heater(unsigned int pin, unsigned int freq);
	~Heater();

	// callback function, control heater on and off
	void ControlHeater();
	// callback function, compute the average, minimum, maximum for 4 temperatures 
	void ProcessTempers(const std::vector<double> &tempers);
	// set gpiopwm, cmd control pwm level, call setPwmLvl()
  void set(char lvl) override;
  void stop() override;

	// Test only
	#ifdef DEBUG
	const unsigned int getPin() {
		return kPin_;
	}

	unsigned int getDutycycle() {
		return dutycycle_;
	}
	#endif

private:
	std::mutex mtx_;
	// average, minimum, maximum
	std::tuple<double, double, double> tempsInfo_;
	std::tuple<double, double> tempRange_ = std::make_tuple<double, double>(24.0, 25.0);
};

#endif