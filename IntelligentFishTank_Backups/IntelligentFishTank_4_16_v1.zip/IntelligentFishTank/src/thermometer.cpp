// opendir
#include <dirent.h>
#include <sys/types.h>
// regex
#include <regex>
// read file
#include <stdexcept>
#include <iostream>
#include <fstream>
#include <thread>
#include "config.h"

#include "thermometer.h"
#include "heater.h"

// Test only
#define DEBUG

Thermometer::Thermometer() : running_(true) {
	FindTempDevices();
}

void Thermometer::registerHeater(std::shared_ptr<Heater> &heater_ptr) {
	heater_ptr_ = heater_ptr;
}

void Thermometer::turnOn() {
	running_ = true;
	ReadAllTemp();
}

void Thermometer::turnOff() {
	running_ = false;
}

void Thermometer::ReadAllTemp() {
	if (device_files_.empty()) {
		throw std::runtime_error("fail to find any DS18B20 device directory!");
	}
	
	while (running_) {
		int index = 0;
		for (auto fileName : device_files_) {
			std::ifstream finput(fileName, std::ifstream::in);
			// open fail
			if (!finput.is_open()) {
				// finput.open(fileName, std::ifstream::in);
				throw std::runtime_error("fail to open temperatur files!");
			}
			// read temperature file and record data
			std::string tmp_temp;
			if (getline(finput, tmp_temp)) {
				// cast type from string to double
				double t = std::stod(tmp_temp) * 1.0 / 1000;
				// std::cout << "temps current size : " << tempers_.size() << " --- geshu ----\n";
				// std::cout << "temperatur files size : " << device_files_.size() << std::endl;
				if (tempers_.size() == device_files_.size()) {
					tempers_[index] = t;
					if (!t) {
						// if read t = 0, especially when initialises programe, read again
						continue;
					}
					// call callback function to control heater
					// std::cout << "ReadAllTemp : " << t << "`C\n"; // here is ok
					heater_ptr_->ProcessTempers(tempers_);
				} else {
					tempers_.push_back(t);
				}
				++index;
			}
			// close temperature file
			finput.close();
		}
	}
}

// find and record thermometer files
void Thermometer::FindTempDevices() {
	// open devices directory
	/*
	 * it's convenient to use raw point when using function `opendir` and `readdir`
	*/
	DIR* dir = nullptr;
	if(!(dir = opendir(app_config::THERMOMETER_DEV_PATH.c_str()))) {
		throw std::runtime_error("failed to opendir!");
	}
	// search valid files in dev directory
	dirent* subpath = nullptr;
	//tmp variable to save device file name
  std::string filename;
	while ((subpath = readdir(dir))) {
		// std::cout << subpath->d_name << std::endl;
		// find directory beginning with "28-"
		std::string pattern("^28-.*$");
		std::regex reg(pattern);
		// match
		if (std::regex_match(subpath->d_name, reg)) {
			filename = app_config::THERMOMETER_DEV_PATH
								+ '/' + static_cast<const std::string>(subpath->d_name)
								+ "/temperature";
			device_files_.push_back(filename);
			// break;  // more than one thermometer
		}
	}
	closedir(dir);
}

Thermometer::~Thermometer() {
	if (running_) {
		running_ = false;
	}
}

// Test only
#ifdef DEBUG
const std::vector<double> &Thermometer::get_temps() const{
  return tempers_;
}

const std::vector<std::string> &Thermometer::get_dev() const{
	return device_files_;
} 
#endif