#include <sys/time.h>

struct itimerval;