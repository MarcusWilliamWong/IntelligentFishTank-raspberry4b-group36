./mjpg_streamer -i "./input_raspicam.so" -o "./output_http.so -w ./www"
