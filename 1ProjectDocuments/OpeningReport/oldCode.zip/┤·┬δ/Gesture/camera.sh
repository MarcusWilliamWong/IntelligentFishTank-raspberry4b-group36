cd /home/pi/mjpg-streamer/mjpg-streamer-experimental
./start.sh
